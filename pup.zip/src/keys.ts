export const keys = {
    type: 'service_account',
    project_id: 'optimal-design-344208',
    private_key_id: 'd4af31cf3905ec3a20cc4d63e9f01c46c87c90c0',
    keepa_key: '1uuk3u3b55cvqn3fbq8ii90v44eeb138r0j5rvgcpjoove9vele1qqu33kmhglc7',
    private_key:
        '-----BEGIN PRIVATE KEY-----\nMIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQCIVYxwGUBtsJgt\nw0EzxsvZ4GdMdoL46iXQKduxZcxZiJ/+1wqgDLHzsHvtY0LHK7YNPd+iEch3yBy2\nz45l7kZ3mbtyZqQ2qw8wQA9YNXqrHHybv499XEUsvcCF9rwgB2V2gyzp3D4ZkcS4\nFYRnJvYRVk/deAunLuY6CsMOBErSMW72P/b+pmJ+mWVWrxKdty7NOf2OdOW8onSj\nEcVbqPMiHyHpihxD+8wuv5CAwrukPUvN9UUS/uURI81w9XHsY0tsTsV0xUgeZARC\nqjd5xnJr+0IBddXWBf2cnjtygMea8b9l6UPd2ZZt7Brb2oCrxVnNu9LI0avHmcDz\nT9Nf+wM7AgMBAAECggEAQ/nHqpLknWx6DAM5TNwXgvxQ9P54Iiz5Cpf8SrCzmYa2\nI4XL7e42ggciW0PtJUqFnIeXrALK3fJgYsQNP4R1DSgRHqLPyNQ0n/2oyPXtQkjT\nVoLGRB6P/RVlW0YhGaUmcVdJOxdNvUkBeTl9SUNTWGSdMJMs2EBZmWIJTEFWnwM9\ngFjcccjCtBuCfuMSuZvF4tSYdUvpEYnOmUr9fQoK6L5asCF3iaKHDs7siXVJ3Hue\nBsSerGPmcRrDwtK+8neW0YGpL+azCmPRaEjSSldBkGOAwcY76X3QROO5NJq7ZLYx\n3LFBYCFf41X8Bhp14TtouO/UtsL60Ic6kG1UJAFc0QKBgQC7O5Zx5va4qdTUJfIw\n2x6yHC/tJUxAYGmb+JMRsg9RLym7cx7daT2mRWi2zU9zJKO6q+wooMnK6N92gvf2\ne8LP4FlKY1iLDZYt5On6njhCrYFlIXmKlJ8SxEg6zAtu7BHy5yCjF9WOgcCGgF1c\n/R39YF7EaeWeMYlKjWuSTnQaEQKBgQC6aELkJVgEM6H0PcALzEhqds14hMuqKcIF\nc08TDbsmAsowtgZnbouscdZ2O5Tx7Cs4O7cs/gPlUXxkRFkzdr/JWmMWCBNIPBwT\ns2P/xZBff1KVgWm1GJxOfSjXLSfCOW6remhDwL/EFkHrm68PZsVl/YH9eKgP1Kcd\n6FK046cciwKBgQCBbGFEfvkRESRzOX++0djYGa/vZ5bb8UlPbXaMBt+bqNRaJOuy\n9WqOIvCNXEKNP0iGYw0t0GdtAahmjYXGNiql81kFmMK97DhhpRkwCmqtfK4zL/6K\nEs4a9N9Q9Xb5x+loVOg0lOckSQDCeL0Q6E7wtMsNTn5Q6cETbcpsKhsLYQKBgQCI\nQagLnqR8xcUvhGe5+ARDFj5RRzicVNPHKid19QaE3WswOg3qUyrzzW6HlDvmrsxU\n2Ymm8LKmUG8N18wgS0Abjd95/kMh/RZE7E8/agmDVM1oDWXYg3nWAbT1vMMgPN0B\nqYNHa0CBtAdRksZfCq9mQu1e+3BVygqyWN0D7ph7ywKBgCaKIx9K2q5d5a5utRHp\nPHLy/lGH/b8eak14As7B0/krQi1HhNH7YoQav1Caq/71Tn+yCl2o2QU0h5KMkabV\nsfD+m7sp0TkRtANJi8VSrxu8VhjmmVRYHP219TORdyOs8lNq0XOVXUhhyxiCjSCK\nTXELGatM96CbI56BF8tn8q8f\n-----END PRIVATE KEY-----\n',
    client_email: 'myrobot@optimal-design-344208.iam.gserviceaccount.com',
    client_id: '103510977075183106896',
    auth_uri: 'https://accounts.google.com/o/oauth2/auth',
    token_uri: 'https://oauth2.googleapis.com/token',
    auth_provider_x509_cert_url: 'https://www.googleapis.com/oauth2/v1/certs',
    client_x509_cert_url:
        'https://www.googleapis.com/robot/v1/metadata/x509/myrobot%40optimal-design-344208.iam.gserviceaccount.com',
}
