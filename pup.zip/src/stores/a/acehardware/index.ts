import Store from '../../Store'
import { EnumLoadType } from '../../../@types/EnumLoadType'

export default class Acehardware extends Store {
    constructor(url: string) {
        super(url)
        this.loadType = EnumLoadType.LOAD
    }

    async productExistCalculate(): Promise<void> {
        await this.productExistBySelector('div[id="pdp-detail-inner"] h1[itemprop="name"]')
    }

    async availibilityCalculate(): Promise<void> {
        await this.checkAvailability({
            selector: 'div.product-add-to-cart-info div:not(.is-loading) > button[id="add-to-cart"]:not(.is-disabled)',
            render: 'text',
            outputArray: [],
        })
        this.availability = true
    }

    async priceCalculate(): Promise<void> {
        await this.checkPrice({
            selector1: '*[itemprop="price"]',
            render: 'text',
        })
    }
}
