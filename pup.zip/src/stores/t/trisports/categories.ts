export const categories = [
    'https://www.trisports.com/bike',
    'https://www.trisports.com/training',
    'https://www.trisports.com/nutrition',
    'https://www.trisports.com/electronics',
    'https://www.trisports.com/run',
    'https://www.trisports.com/apparel',
    'https://www.trisports.com/accessories',
    'https://www.trisports.com/swim',
    'https://www.trisports.com/brands',
]
