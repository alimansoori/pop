import { CheerioAPI } from 'cheerio'

export type TypePostmanReq = {
    $: CheerioAPI
    headers: object
    error: boolean
}
