interface IPuppeteerConfig {
    zyte_api_key: string
    zyte_proxy_host: string
    zyte_proxy_port: string
}
