export default class AmazonCategory {
    static categoryLists(): string[] {
        return [
            'Appliances',
            'Apps & Games',
            'Arts, Crafts & Sewing',
            'Automotive',
            'Baby Products',
            'Baby',
            'Beauty & Personal Care',
            'Books',
            'Cell Phones & Accessories',
            'Clothing, Shoes & Jewelry',
            'Electronics',
            'Grocery & Gourmet Food',
            'Health & Household',
            'Home & Kitchen',
            'Industrial & Scientific',
            'Musical Instruments',
            'Office Products',
            'Patio, Lawn & Garden',
            'Pet Supplies',
            'Sports & Outdoors',
            'Tools & Home Improvement',
            'Toys & Games',
            'Video Games',
            'Home & Kitchen',
        ]
    }
}
