type IProductInput = IProductAmazonOutput
