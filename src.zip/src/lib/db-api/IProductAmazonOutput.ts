interface IProductAmazonOutput {
    asin?: string
    brand?: string
    category?: string
    description?: string
    id?: string
    images?: string[]
    link: string
    src?: string
    title: string
    upcList?: string[]
}
