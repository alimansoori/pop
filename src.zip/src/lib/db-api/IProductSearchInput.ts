interface IProductSearchInput {
    search: string
    src?: string
    reverseSrc?: boolean
}
