interface IProductSearchOutput {
    score: number
    similarity: number
    t: IProductAmazonOutput
}
