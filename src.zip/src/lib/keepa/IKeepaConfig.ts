interface IKeepaConfig {
    keepa_api_key: string
    keepa_api_url: string
}
