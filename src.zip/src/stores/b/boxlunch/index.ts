import Store from '../../Store'

import { EnumLoadType } from '../../../@types/EnumLoadType'

export default class Boxlunch extends Store {
    constructor(url: string) {
        super(url)
        this.loadType = EnumLoadType.DOC_LOADED
        this.scrapUntilBlock = true
    }

    async productExistCalculate(): Promise<void> {
        await this.productExistBySelector('h1.product-name')
    }

    async availibilityCalculate(): Promise<void> {
        await this.checkMetaByClassSchemas('script[type="application/ld+json"]')

        await this.checkAvailability({
            selector: 'div.availability-msg-text.instock',
            render: null,
            outputArray: [],
        })
    }
}
