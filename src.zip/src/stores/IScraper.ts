export default interface IScraper {
    scrap(): void
    scrapPageProducts(): void
    scrapPageProductDetail(): void
}
