export default interface IStoreOptions {
    setIsCategoryTreeNavigate(isTree: boolean): this
    hasCategoryTreeNavigate(): boolean
}
