export const categories = [
    'https://www.myotcstore.com/senior-store/',
    'https://www.myotcstore.com/sale/',
    'https://www.myotcstore.com/household/',
    'https://www.myotcstore.com/supplements-fitness/',
    'https://www.myotcstore.com/home-medical/',
    'https://www.myotcstore.com/baby-mother/',
    'https://www.myotcstore.com/skin-beauty/',
    'https://www.myotcstore.com/medicine-cabinet/',
]
