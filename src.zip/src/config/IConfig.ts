export interface IConfig {
    mongo_username: string
    mongo_password: string
    mongo_db: string
    mongo_host: string
    mongo_port: string
}
