export enum EnumLoadType {
    LOAD = 'load',
    DOC_LOADED = 'domcontentloaded',
    NET0 = 'networkidle0',
    NET2 = 'networkidle0',
}
