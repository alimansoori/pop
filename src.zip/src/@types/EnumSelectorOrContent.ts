export enum EnumSelectorOrContent {
    SELECTOR,
    CONTENT,
}
