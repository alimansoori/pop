export type KeepaInputType = {
    asin: string
    sourcePrice: number
}
