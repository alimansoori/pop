export type GoogleInputType = {
    title: string
}
